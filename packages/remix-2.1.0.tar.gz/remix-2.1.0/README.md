# Welcome to Echo Nest Remix

Echo Nest Remix is **the Internet Synthesizer.** 
Make amazing things from music, automatically.  Turn any music or video into Python, Flash, or Javascript code.  

Want more cowbell? [Remix can do it.](http://www.morecowbell.dj/ "")  
Want to make it swing? [Remix can do it.](http://swingify.cloudapp.net/ "")  
Want to turn any track into drum & bass? [Remix can do it.](http://the.wubmachine.com/ "")  
Want to make new music videos out of old ones? [Remix can do it.](http://www.youtube.com/watch?v=_bW7AkhgQpc/ "")  

## Getting Started
We've made a shiny new page for getting Remix installed: <http://echonest.github.com/remix/>  
We've just pushed Remix 2.0.0 - if you have any problems, let us know!

![""](https://a248.e.akamai.net/camo.github.com/c7a3810cd59b15375246e5468b46cdecd18edbb9/687474703a2f2f692e696d6775722e636f6d2f57574c596f2e676966 "Head-nodding cat can't believe that he hasn't been remixed yet")

